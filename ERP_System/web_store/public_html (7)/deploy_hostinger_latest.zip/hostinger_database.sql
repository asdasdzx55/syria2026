-- ============================================================
-- Syrian Home Supermarket Database Schema & Seed Data (MySQL)
-- Generated: 2026-08-17 01:04:28
-- ============================================================

SET FOREIGN_KEY_CHECKS = 0;

-- ------------------------------------------------------------
-- Table: `users`
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(100) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `email` VARCHAR(150) DEFAULT NULL,
  `role` VARCHAR(20) DEFAULT 'admin',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` (`id`, `username`, `password`, `role`, `email`, `phone`, `street`, `building`, `floor`, `apartment`, `landmark`, `gov_id`, `country`) VALUES
('1', 'admin', '$2y$10$DsJXcexEU6nZjbtOLI7zU.xNYnJ5uckBar6xek2Gya7Xvd39bgq3y', 'admin', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'مصر');

-- ------------------------------------------------------------
-- Table: `categories`
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(150) NOT NULL,
  `parent_id` INT DEFAULT NULL,
  `image_url` VARCHAR(255) DEFAULT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `categories` (`id`, `name`, `image_url`, `parent_id`) VALUES
('1', 'أجبان وألبان شامية', 'placeholder.php?w=400&h=300&text=أجبان+شامية', NULL),
('2', 'مكدوس وزيوت وزيتون', 'placeholder.php?w=400&h=300&text=زيوت+ومكدوس', NULL),
('3', 'بهارات وعطارة حلبية', 'placeholder.php?w=400&h=300&text=بهارات+وعطارة', NULL),
('4', 'حلويات وموالح دمشقية', 'placeholder.php?w=400&h=300&text=حلويات+وموالح', NULL),
('5', 'مؤونة ومعلبات شامية', 'placeholder.php?w=400&h=300&text=مؤونة+ومعلبات', NULL),
('6', 'بن ومشروبات سورية', 'placeholder.php?w=400&h=300&text=بن+ومشروبات', NULL),
('7', 'حبوب وبقوليات وتموين', 'placeholder.php?w=400&h=300&text=بقوليات+وتموين', NULL),
('8', 'منظفات وعناية منزلية', 'placeholder.php?w=400&h=300&text=منظفات+منزلية', NULL);

-- ------------------------------------------------------------
-- Table: `products`
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL,
  `category` VARCHAR(100) NOT NULL,
  `sub_category` VARCHAR(100) DEFAULT NULL,
  `description` TEXT,
  `price` DECIMAL(10,2) NOT NULL,
  `old_price` DECIMAL(10,2) DEFAULT NULL,
  `cost` DECIMAL(10,2) DEFAULT 0.00,
  `stock` DECIMAL(10,2) DEFAULT 100.00,
  `barcode` VARCHAR(100) DEFAULT NULL,
  `barcode2` VARCHAR(100) DEFAULT NULL,
  `barcode3` VARCHAR(100) DEFAULT NULL,
  `all_barcodes` TEXT,
  `local_code` VARCHAR(50) DEFAULT NULL,
  `is_pos_visible` TINYINT(1) DEFAULT 1,
  `synced` INT DEFAULT 1,
  `image_url` VARCHAR(500),
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `products` (`id`, `name`, `category`, `description`, `price`, `old_price`, `image_url`, `created_at`, `sub_category`, `barcode`, `barcode2`, `barcode3`, `all_barcodes`, `local_code`, `cost`, `stock`, `is_pos_visible`, `synced`) VALUES
('1', 'جبنة حلوم بلدية سورية فاخرة 500جم', 'أجبان وألبان شامية', 'جبنة حلوم سورية طبيعية 100% للشواء والقلي، طعم شامي أصيل وغني بالكالسيوم.', '95', '110', 'placeholder.php?w=600&h=600&text=جبنة+حلوم+شامية', '2026-08-17 01:03:15', 'أجبان بلدية', '6221000123456', '6221000123457', NULL, '6221000123456,6221000123457,10001', '10001', '75', '80', '1', '1'),
('2', 'جبنة شلل سورية حبة بركة 400جم', 'أجبان وألبان شامية', 'جبنة شلل حموية أصيلة محلاة ومتبلة بحبة البركة والمحلب، مثالية للمائدة الشامية.', '110', '130', 'placeholder.php?w=600&h=600&text=جبنة+شلل+سورية', '2026-08-17 01:03:15', 'أجبان بلدية', '6222000234567', '', NULL, '6222000234567,10002', '10002', '88', '65', '1', '1'),
('3', 'مكدوس سوري بلدي بالجوز وزيت الزيتون 1 كجم', 'مكدوس وزيوت وزيتون', 'مكدوس باذنجان بلدي محشو بأجود أنواع الجوز والفليفلة الحلبية ومكبوس بزيت الزيتون البكر.', '160', '185', 'placeholder.php?w=600&h=600&text=مكدوس+سوري+بلدي', '2026-08-17 01:03:15', 'مكدوس ومخللات', '6223000345678', '', NULL, '6223000345678,10003', '10003', '125', '50', '1', '1'),
('4', 'زيت زيتون بكر ممتاز إدلبي عصرة أولى 1 لتر', 'مكدوس وزيوت وزيتون', 'زيت زيتون إدلبي أصلي عصرة أولى على البارد بنسبة حموضة أقل من 0.8%، طعم ورائحة لا تقاوم.', '260', '290', 'placeholder.php?w=600&h=600&text=زيت+زيتون+إدلبي', '2026-08-17 01:03:15', 'زيوت بلدية', '6224000456789', '', NULL, '6224000456789,10004', '10004', '210', '90', '1', '1'),
('5', 'زعتر حلبي اكسترا بالمكسرات والسمسم 500جم', 'بهارات وعطارة حلبية', 'زعتر حلبي أحمر ملكي غني بالفستق الحلبي واللوز والسمسم المحمص والبهارات الشرقية.', '75', '90', 'placeholder.php?w=600&h=600&text=زعتر+حلبي+اكسترا', '2026-08-17 01:03:15', 'زعتر ودقة', '6225000567890', '', NULL, '6225000567890,10005', '10005', '55', '110', '1', '1'),
('6', 'دبس رمان شامي طبيعي مركز 500 مل', 'مؤونة ومعلبات شامية', 'دبس رمان طبيعي 100% بدون سكر مضاف، مذاق حامض حلو رائع للسلطات والمشاوي والفتوش.', '85', '100', 'placeholder.php?w=600&h=600&text=دبس+رمان+شامي', '2026-08-17 01:03:15', 'صلصات ودبس', '6226000678901', '', NULL, '6226000678901,10006', '10006', '65', '70', '1', '1'),
('7', 'لبنة بلدية شامية مكبوسة بالزيت (بالوزن/كجم)', 'أجبان وألبان شامية', 'كرات اللبنة السورية المدعبلة بزيت الزيتون الصافي والنعناع وحبة البركة.', '220', '250', 'placeholder.php?w=600&h=600&text=لبنة+بلدية+شامية', '2026-08-17 01:03:15', 'ألبان ولبنة', '00101', '', NULL, '00101,10007', '10007', '175', '30', '1', '1'),
('8', 'زيتون عطون حلبي مخلل فاخر (بالوزن/كجم)', 'مكدوس وزيوت وزيتون', 'زيتون أسود عطون حلبي مكبوس بالملح البحري وزيت الزيتون بطريقة تقليدية عريقة.', '130', '150', 'placeholder.php?w=600&h=600&text=زيتون+عطون+حلبي', '2026-08-17 01:03:15', 'زيتون ومخللات', '00102', '', NULL, '00102,10008', '10008', '95', '45', '1', '1'),
('9', 'راحة دمشقية بالفستق الحلبي والمستكة (بالوزن/كجم)', 'حلويات وموالح دمشقية', 'راحة الحلقوم الدمشقية الأصلية محشوة بالفستق الحلبي المقرمش ونكهة ماء الزهر والمستكة.', '320', '360', 'placeholder.php?w=600&h=600&text=راحة+دمشقية+بالفستق', '2026-08-17 01:03:15', 'راحة وحلويات', '00104', '', NULL, '00104,10010', '10010', '250', '20', '1', '1'),
('10', 'بن شامي فاخر بالهيل والمسك 250جم', 'بن ومشروبات سورية', 'توليفة قهوة شامية محوجة بأفخر حبات الهيل الأخضر ولمسة مسك دمشقي عطرية.', '120', '140', 'placeholder.php?w=600&h=600&text=بن+شامي+بالهيل', '2026-08-17 01:03:15', 'قهوة وبن', '6227000789012', '', NULL, '6227000789012,10011', '10011', '95', '60', '1', '1'),
('11', 'ملوخية شامية يابسة ورقة كاملة 400جم', 'مؤونة ومعلبات شامية', 'ملوخية سورية مجففة خضراء ورقة كاملة خالية من الشوائب ومجففة بالظل للحفاظ على النكهة.', '65', '80', 'placeholder.php?w=600&h=600&text=ملوخية+شامية+مجففة', '2026-08-17 01:03:15', 'مؤونة مجففة', '6229000901234', '', NULL, '6229000901234,10013', '10013', '48', '85', '1', '1'),
('12', 'فريك حوراني بلدي منقى 1 كجم', 'حبوب وبقوليات وتموين', 'فريك حوراني سوري مشوي على الحطب ذو حبة خضراء ممتلئة ونكهة مدخنة رائعة.', '80', '95', 'placeholder.php?w=600&h=600&text=فريك+حوراني+بلدي', '2026-08-17 01:03:15', 'حبوب وبقوليات', '6230000012345', '', NULL, '6230000012345,10014', '10014', '60', '100', '1', '1'),
('13', 'سمن بقري حماوي بلدي نقي 800جم', 'أجبان وألبان شامية', 'سمن بقري حماوي بلدي صافي برائحة زكية وقوام مرمل مثالي للحلويات والمأكولات الشامية.', '290', '330', 'placeholder.php?w=600&h=600&text=سمن+حماوي+بلدي', '2026-08-17 01:03:15', 'سمن وزبدة', '6232000223344', '', NULL, '6232000223344,10016', '10016', '240', '40', '1', '1'),
('14', 'بهارات شاورما سورية مشكلة 200جم', 'بهارات وعطارة حلبية', 'تتبيلة شاورما دجاج ولحم سورية سرية على أصولها لمذاق المطاعم الشامية الشهيرة.', '45', '55', 'placeholder.php?w=600&h=600&text=بهارات+شاورما+سورية', '2026-08-17 01:03:15', 'خلطات بهارات', '6233000334455', '', NULL, '6233000334455,10017', '10017', '32', '90', '1', '1'),
('15', 'قمر الدين غوطاني دمشقي فاخر 400جم', 'حلويات وموالح دمشقية', 'قمر الدين سوري طبيعي من مشمش غوطة دمشق المشهور، طعم غني ولون ذهبي رائع.', '55', '65', 'placeholder.php?w=600&h=600&text=قمر+الدين+غوطاني', '2026-08-17 01:03:15', 'مشمش وقمر الدين', '6234000445566', '', NULL, '6234000445566,10018', '10018', '40', '130', '1', '1');

-- ------------------------------------------------------------
-- Table: `product_images`
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `product_images`;
CREATE TABLE `product_images` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `product_images` (`id`, `product_id`, `image_path`, `is_main`) VALUES
('1', '1', 'placeholder.php?w=600&h=600&text=جبنة+حلوم+شامية', '1'),
('2', '2', 'placeholder.php?w=600&h=600&text=جبنة+شلل+سورية', '1'),
('3', '3', 'placeholder.php?w=600&h=600&text=مكدوس+سوري+بلدي', '1'),
('4', '4', 'placeholder.php?w=600&h=600&text=زيت+زيتون+إدلبي', '1'),
('5', '5', 'placeholder.php?w=600&h=600&text=زعتر+حلبي+اكسترا', '1'),
('6', '6', 'placeholder.php?w=600&h=600&text=دبس+رمان+شامي', '1'),
('7', '7', 'placeholder.php?w=600&h=600&text=لبنة+بلدية+شامية', '1'),
('8', '8', 'placeholder.php?w=600&h=600&text=زيتون+عطون+حلبي', '1'),
('9', '9', 'placeholder.php?w=600&h=600&text=راحة+دمشقية+بالفستق', '1'),
('10', '10', 'placeholder.php?w=600&h=600&text=بن+شامي+بالهيل', '1'),
('11', '11', 'placeholder.php?w=600&h=600&text=ملوخية+شامية+مجففة', '1'),
('12', '12', 'placeholder.php?w=600&h=600&text=فريك+حوراني+بلدي', '1'),
('13', '13', 'placeholder.php?w=600&h=600&text=سمن+حماوي+بلدي', '1'),
('14', '14', 'placeholder.php?w=600&h=600&text=بهارات+شاورما+سورية', '1'),
('15', '15', 'placeholder.php?w=600&h=600&text=قمر+الدين+غوطاني', '1');

-- ------------------------------------------------------------
-- Table: `product_variants`
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `product_variants`;
CREATE TABLE `product_variants` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Table: `orders`
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `customer_name` VARCHAR(255) NOT NULL,
  `customer_phone` VARCHAR(50) NOT NULL,
  `customer_email` VARCHAR(255) DEFAULT NULL,
  `country` VARCHAR(100) DEFAULT 'مصر',
  `currency` VARCHAR(50) DEFAULT 'ج.م',
  `governorate` VARCHAR(100) DEFAULT 'القاهرة',
  `customer_address` TEXT,
  `order_details` TEXT NOT NULL,
  `total_price` DECIMAL(10,2) NOT NULL,
  `discount_amount` DECIMAL(10,2) DEFAULT 0,
  `shipping_cost` DECIMAL(10,2) DEFAULT 0,
  `coupon_code` VARCHAR(50) DEFAULT NULL,
  `payment_method` VARCHAR(100) DEFAULT 'كاش',
  `payment_status` VARCHAR(50) DEFAULT 'غير مدفوع',
  `receipt_image` VARCHAR(500) DEFAULT NULL,
  `transaction_ref` VARCHAR(250) DEFAULT NULL,
  `delivery_lat` VARCHAR(50) DEFAULT NULL,
  `delivery_lng` VARCHAR(50) DEFAULT NULL,
  `delivery_distance_km` DECIMAL(10,2) DEFAULT NULL,
  `shipping_type` VARCHAR(50) DEFAULT 'flat',
  `status` VARCHAR(50) DEFAULT 'جديد',
  `source` VARCHAR(50) DEFAULT 'web',
  `cashier_name` VARCHAR(100) DEFAULT NULL,
  `delivery_person` VARCHAR(100) DEFAULT NULL,
  `delivery_fee` DECIMAL(10,2) DEFAULT 0,
  `synced` INT DEFAULT 1,
  `user_id` INT DEFAULT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Table: `reviews`
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `reviews`;
CREATE TABLE `reviews` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Table: `coupons`
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `coupons`;
CREATE TABLE `coupons` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Table: `shipping_zones`
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `shipping_zones`;
CREATE TABLE `shipping_zones` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `shipping_zones` (`id`, `gov_name`, `cost`, `is_active`, `country_name`, `country_code`, `currency_symbol`) VALUES
('1', 'القاهرة', '50', '1', 'مصر', 'EG', 'ج.م'),
('2', 'الجيزة', '50', '1', 'مصر', 'EG', 'ج.م'),
('3', '6 أكتوبر', '50', '1', 'مصر', 'EG', 'ج.م'),
('4', 'الشيخ زايد', '50', '1', 'مصر', 'EG', 'ج.م'),
('5', 'الإسكندرية', '50', '1', 'مصر', 'EG', 'ج.م'),
('6', 'القليوبية', '50', '1', 'مصر', 'EG', 'ج.م'),
('7', 'الدقهلية', '50', '1', 'مصر', 'EG', 'ج.م'),
('8', 'الشرقية', '50', '1', 'مصر', 'EG', 'ج.م'),
('9', 'الغربية', '50', '1', 'مصر', 'EG', 'ج.م'),
('10', 'المنوفية', '50', '1', 'مصر', 'EG', 'ج.م'),
('11', 'البحيرة', '50', '1', 'مصر', 'EG', 'ج.م'),
('12', 'كفر الشيخ', '50', '1', 'مصر', 'EG', 'ج.م'),
('13', 'دمياط', '50', '1', 'مصر', 'EG', 'ج.م'),
('14', 'الإسماعيلية', '50', '1', 'مصر', 'EG', 'ج.م'),
('15', 'بورسعيد', '50', '1', 'مصر', 'EG', 'ج.م'),
('16', 'السويس', '50', '1', 'مصر', 'EG', 'ج.م'),
('17', 'شمال سيناء', '50', '1', 'مصر', 'EG', 'ج.م'),
('18', 'جنوب سيناء', '50', '1', 'مصر', 'EG', 'ج.م'),
('19', 'بني سويف', '50', '1', 'مصر', 'EG', 'ج.م'),
('20', 'المنيا', '50', '1', 'مصر', 'EG', 'ج.م'),
('21', 'الفيوم', '50', '1', 'مصر', 'EG', 'ج.م'),
('22', 'أسيوط', '50', '1', 'مصر', 'EG', 'ج.م'),
('23', 'سوهاج', '50', '1', 'مصر', 'EG', 'ج.م'),
('24', 'قنا', '50', '1', 'مصر', 'EG', 'ج.م'),
('25', 'الأقصر', '50', '1', 'مصر', 'EG', 'ج.م'),
('26', 'أسوان', '50', '1', 'مصر', 'EG', 'ج.م'),
('27', 'البحر الأحمر', '50', '1', 'مصر', 'EG', 'ج.م'),
('28', 'الوادي الجديد', '50', '1', 'مصر', 'EG', 'ج.م'),
('29', 'مرسى مطروح', '50', '1', 'مصر', 'EG', 'ج.م');

-- ------------------------------------------------------------
-- Table: `home_slides`
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `home_slides`;
CREATE TABLE `home_slides` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `home_slides` (`id`, `image_url`, `title`, `subtitle`, `link_url`, `sort_order`) VALUES
('1', 'placeholder.php?w=1920&h=800&text=سوبر+ماركت+المنزل+السوري', 'أهلاً بكم في سوبر ماركت المنزل السوري', 'كل ما تشتهيه من خيرات ومؤونة بلاد الشام الطازجة بين يديك', 'shop.php', '0'),
('2', 'placeholder.php?w=1920&h=800&text=أجبان+وألبان+شامية+طازجة', 'تشكيلة الأجبان والألبان والمكدوس البلدي', 'حلوم، شلل، قشقوان، مكدوس بالجوز، وزيت زيتون إدلبي بكر', 'shop.php?category=%D8%A3%D8%AC%D8%A8%D8%A7%D9%86+%D9%88%D8%A3%D9%84%D8%A8%D8%A7%D9%86+%D8%B4%D8%A7%D9%85%D9%8A%D8%A9', '0');

-- ------------------------------------------------------------
-- Table: `settings`
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `key_name` VARCHAR(50) PRIMARY KEY,
  `setting_value` TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `settings` (`key_name`, `setting_value`) VALUES
('store_logo', ''),
('store_favicon', ''),
('store_currency', 'ج.م'),
('theme_header_text', '#ffffff'),
('theme_body_bg', '#fef2f2'),
('theme_card_bg', '#ffffff'),
('theme_btn_text', '#ffffff'),
('home_banner', 'placeholder.php?w=1920&h=800'),
('contact_phone', ''),
('contact_email', ''),
('social_whatsapp', ''),
('social_facebook', ''),
('social_instagram', ''),
('policy_return', ''),
('policy_shipping', ''),
('groq_api_key', ''),
('ai_chat_enabled', '0'),
('meta_pixel_id', ''),
('meta_pixel_enabled', '0'),
('cod_enabled', '1'),
('vodafone_cash_enabled', '0'),
('vodafone_cash_number', ''),
('instapay_enabled', '0'),
('instapay_address', ''),
('instapay_name', ''),
('paymob_enabled', '0'),
('paymob_api_key', ''),
('paymob_integration_id_card', ''),
('paymob_integration_id_wallet', ''),
('paymob_iframe_id', ''),
('enable_km_shipping', '1'),
('store_lat', '30.0444'),
('store_lng', '31.2357'),
('store_address_name', 'الفرع الرئيسي / مركز الشحن والتوزيع'),
('km_rate', '2'),
('km_base_min_price', '25'),
('km_shipping_govs', '["القاهرة", "الجيزة", "6 أكتوبر", "الشيخ زايد", "القليوبية"]'),
('default_country', 'مصر'),
('enable_multi_country', '0'),
('preferred_currency_mode', 'fixed'),
('active_countries', '["مصر"]'),
('cham_cash_enabled', '0'),
('cham_cash_number', ''),
('cham_cash_name', ''),
('syriatel_cash_number', ''),
('paypal_enabled', '0'),
('paypal_email', ''),
('paypal_client_id', ''),
('policy_payment', '• نوفر وسائل دفع متعددة وآمنة تناسب عملائنا في جمهورية مصر العربية: الدفع نقداً عند الاستلام (كاش)، المحافظ الإلكترونية (فودافون كاش وغيرها)، تحويل إنستا باي (InstaPay)، وبطاقات الدفع الإلكتروني (فيزا / ماستركارد / ميزة) عبر بوابة Paymob المعتمدة.\n• جميع المعاملات البنكية والمدفوعات مشفرة ومحمية بأعلى بروتوكولات الأمان والحماية المصرفية والتشفير العالمي SSL.\n• لا نقوم بحفظ أو تخزين أي بيانات للبطاقات الائتمانية أو الحسابات البنكية على خوادمنا نهائياً.'),
('policy_privacy', '• نلتزم التزاماً تاماً بحماية خصوصية وأمان بياناتك الشخصية والحفاظ على سريتها المطلقة.\n• تُستخدم بياناتك المسجلة (الاسم، الهاتف، العنوان، البريد) فقط لغرض معالجة وتجهيز وتوصيل طلباتك وتقديم الدعم الفني.\n• نتعهد بعدم بيع أو تأجير أو مشاركة بياناتك الشخصية مع أي جهة خارجية أو أطراف ثالثة لأغراض إعلانية.'),
('policy_terms', '• باستخدامك لهذا المتجر وإتمام أي طلب شراء، فإنك توافق على الالتزام بكافة الشروط والأحكام والسياسات المعلنة وفقاً للقوانين المصرية المعمول بها.\n• نحتفظ بالحق في تعديل أو تحديث أسعار المنتجات والعروض الترويجية ومواصفات السلع وفقاً لحالة المخزون المتاح.\n• كافة المحتويات والتصميمات والعلامات التجارية المنشورة على المتجر محمية بموجب حقوق الملكية الفكرية.'),
('store_name', 'سوبر ماركت'),
('store_tagline', 'وجهتك الأولى لكافة المنتجات الغذائية والمواد التموينية الطازجة'),
('store_description', 'سوبر ماركت - تشكيلة شاملة من المواد الغذائية والتموينية، الخضار والفواكه، اللحوم والأجبان والألبان بأعلى جودة وأفضل الأسعار.'),
('announcement_bar', '🌟 أهلاً بكم في متجرنا الإلكتروني - أفضل العروض والخصومات وتوصيل سريع لباب المنزل!'),
('theme_primary_color', '#15803d'),
('theme_secondary_color', '#166534'),
('theme_accent_color', '#d97706'),
('theme_header_bg', '#0f172a'),
('theme_btn_color', '#15803d'),
('api_secret_key', 'syrian_home_pos_secret_token_2026');

-- ------------------------------------------------------------
-- Table: `notifications`
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Table: `visitor_logs`
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `visitor_logs`;
CREATE TABLE `visitor_logs` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `visitor_logs` (`id`, `ip_address`, `user_id`, `page_url`, `device_type`, `created_at`) VALUES
('1', '::1', NULL, 'index.php', 'كمبيوتر', '2026-08-16 23:44:34'),
('2', '::1', NULL, 'index.php', 'كمبيوتر', '2026-08-16 23:45:38'),
('3', '::1', '1', 'index.php', 'كمبيوتر', '2026-08-16 23:47:18'),
('4', '::1', '1', 'profile.php', 'كمبيوتر', '2026-08-16 23:47:25'),
('5', '::1', '1', 'index.php', 'كمبيوتر', '2026-08-16 23:48:18'),
('6', '::1', '1', 'profile.php', 'كمبيوتر', '2026-08-16 23:48:34'),
('7', '::1', '1', 'index.php', 'كمبيوتر', '2026-08-16 23:49:19'),
('8', '::1', NULL, 'login.php', 'كمبيوتر', '2026-08-16 23:56:42'),
('9', '::1', '1', 'index.php', 'كمبيوتر', '2026-08-16 23:57:09'),
('10', '::1', '1', 'index.php', 'كمبيوتر', '2026-08-16 23:58:15'),
('11', '::1', '1', 'index.php', 'كمبيوتر', '2026-08-17 00:02:52'),
('12', '::1', '1', 'index.php', 'كمبيوتر', '2026-08-17 00:20:12'),
('13', '::1', '1', 'shop.php', 'كمبيوتر', '2026-08-17 00:30:10'),
('14', '::1', '1', 'index.php', 'كمبيوتر', '2026-08-17 00:30:11'),
('15', '::1', '1', 'profile.php', 'كمبيوتر', '2026-08-17 00:30:16'),
('16', '::1', '1', 'index.php', 'كمبيوتر', '2026-08-17 00:31:15'),
('17', '::1', '1', 'track.php', 'كمبيوتر', '2026-08-17 00:31:20'),
('18', '::1', NULL, 'policies.php', 'كمبيوتر', '2026-08-17 00:35:17'),
('19', '::1', '1', 'index.php', 'كمبيوتر', '2026-08-17 00:38:23'),
('20', '::1', NULL, 'index.php', 'كمبيوتر', '2026-08-17 00:51:16'),
('21', '::1', NULL, 'shop.php', 'كمبيوتر', '2026-08-17 00:51:16'),
('22', '::1', NULL, 'policies.php', 'كمبيوتر', '2026-08-17 00:51:16'),
('23', '::1', NULL, 'login.php', 'كمبيوتر', '2026-08-17 00:51:16'),
('24', '::1', NULL, 'register.php', 'كمبيوتر', '2026-08-17 00:51:16'),
('25', '::1', NULL, 'cart.php', 'كمبيوتر', '2026-08-17 00:51:16'),
('26', '::1', NULL, 'track.php', 'كمبيوتر', '2026-08-17 00:51:16'),
('27', '::1', '1', 'index.php', 'كمبيوتر', '2026-08-17 00:52:31');

-- ------------------------------------------------------------
-- Table: `wishlist`
-- ------------------------------------------------------------
-- ------------------------------------------------------------
-- Table: `delivery_drivers`
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `delivery_drivers`;
CREATE TABLE `delivery_drivers` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL UNIQUE,
  `phone` VARCHAR(50) DEFAULT NULL,
  `pin_code` VARCHAR(20) DEFAULT '1234',
  `is_active` TINYINT DEFAULT 1,
  `cash_balance` DECIMAL(10,2) DEFAULT 0.00,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `delivery_drivers` (`id`, `name`, `phone`, `pin_code`, `cash_balance`) VALUES
('1', 'كابتن حسام السريع', '01012345678', '1111', '0.00'),
('2', 'كابتن طارق الدليفري', '01023456789', '2222', '0.00'),
('3', 'كابتن محمود الشامي', '01034567890', '3333', '0.00');

SET FOREIGN_KEY_CHECKS = 1;
